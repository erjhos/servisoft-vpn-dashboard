const mongoose = require('mongoose');

const metricSchema = new mongoose.Schema({
  vpnTunnelId: { type: mongoose.Schema.Types.ObjectId, ref: 'VpnTunnel', required: true },
  timestamp: { type: Date, default: Date.now },
  latencia: Number,
  jitter: Number,
  packetLoss: Number,
  throughput: Number,
  estadoPaquetes: { enviados: Number, recibidos: Number, perdidos: Number }
});

metricSchema.index({ vpnTunnelId: 1, timestamp: -1 });

module.exports = mongoose.model('Metric', metricSchema);