const mongoose = require('mongoose');

const vpnTunnelSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  estado: { type: String, enum: ['activo', 'inactivo', 'error'], default: 'inactivo' },
  origen: {
    proveedor: { type: String, enum: ['AWS', 'Azure', 'GCP'] },
    subnet: String,
    ip_publica: String
  },
  destino: {
    proveedor: { type: String, enum: ['AWS', 'Azure', 'GCP'] },
    subnet: String,
    ip_publica: String
  },
  protocolo: { type: String, default: 'IPsec' },
  encriptacion: { type: String, enum: ['AES-128', 'AES-192', 'AES-256'], default: 'AES-256' },
  latencia_ms: { type: Number, default: 0 },
  disponibilidad_pct: { type: Number, default: 0 },
  ultimaActualizacion: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('VpnTunnel', vpnTunnelSchema);