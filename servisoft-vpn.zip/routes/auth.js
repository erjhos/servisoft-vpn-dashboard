const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const router = express.Router();

// Registro
router.post('/register', async (req, res) => {
  try {
    const { nombre, email, password, rol } = req.body;
    
    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ error: 'Usuario ya existe' });

    user = new User({ nombre, email, password, rol });
    await user.save();

    const token = jwt.sign({ id: user._id, rol: user.rol }, process.env.JWT_SECRET || 'secret', {
      expiresIn: '7d'
    });

    res.status(201).json({ token, user: { id: user._id, nombre, email, rol } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Credenciales inválidas' });

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(400).json({ error: 'Credenciales inválidas' });

    const token = jwt.sign({ id: user._id, rol: user.rol }, process.env.JWT_SECRET || 'secret', {
      expiresIn: '7d'
    });

    res.json({ token, user: { id: user._id, nombre: user.nombre, email, rol: user.rol } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;