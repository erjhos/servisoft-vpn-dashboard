const express = require('express');
const router = express.Router();

// Modelo BGP simulado
const bgpRoutes = [
  { id: 1, destino: '10.0.0.0/16', asn: 65000, estado: 'establecido', timestamp: new Date() },
  { id: 2, destino: '172.16.0.0/16', asn: 65001, estado: 'establecido', timestamp: new Date() }
];

router.get('/', (req, res) => {
  res.json(bgpRoutes);
});

router.post('/', (req, res) => {
  const newRoute = { id: bgpRoutes.length + 1, ...req.body, timestamp: new Date() };
  bgpRoutes.push(newRoute);
  res.status(201).json(newRoute);
});

module.exports = router;