const express = require('express');
const VpnTunnel = require('../models/VpnTunnel');
const Metric = require('../models/Metric');

const router = express.Router();

// Obtener todos los túneles
router.get('/', async (req, res) => {
  try {
    const tunnels = await VpnTunnel.find();
    res.json(tunnels);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Crear nuevo túnel
router.post('/', async (req, res) => {
  try {
    const tunnel = new VpnTunnel(req.body);
    await tunnel.save();
    res.status(201).json(tunnel);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Actualizar estado de túnel
router.patch('/:id', async (req, res) => {
  try {
    const tunnel = await VpnTunnel.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(tunnel);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obtener métricas de un túnel
router.get('/:id/metrics', async (req, res) => {
  try {
    const metrics = await Metric.find({ vpnTunnelId: req.params.id })
      .sort({ timestamp: -1 })
      .limit(100);
    res.json(metrics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;