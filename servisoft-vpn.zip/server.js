const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Conexión MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/servisoft-vpn')
  .then(() => console.log('✓ MongoDB conectado'))
  .catch(err => console.error('✗ Error MongoDB:', err));

// Rutas
app.use('/api/auth', require('./routes/auth'));
app.use('/api/vpn-tunnels', require('./routes/vpnTunnels'));
app.use('/api/metrics', require('./routes/metrics'));
app.use('/api/bgp-routes', require('./routes/bgpRoutes'));
app.use('/api/reports', require('./routes/reports'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Servidor ejecutándose en puerto ${PORT}`));

module.exports = app;