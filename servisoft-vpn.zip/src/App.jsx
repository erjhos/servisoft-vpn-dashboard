import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import VpnTunnels from './pages/VpnTunnels';
import Metrics from './pages/Metrics';
import BgpRoutes from './pages/BgpRoutes';
import Reports from './pages/Reports';
import Login from './pages/Login';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('token'));

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
        {isAuthenticated ? (
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/vpn-tunnels" element={<VpnTunnels />} />
            <Route path="/metrics" element={<Metrics />} />
            <Route path="/bgp-routes" element={<BgpRoutes />} />
            <Route path="/reports" element={<Reports />} />
          </Route>
        ) : null}
      </Routes>
    </Router>
  );
}

export default App;