import { Outlet, Link, useNavigate } from 'react-router-dom';
import { LogOut, BarChart3, Wifi, Activity, Route, FileText } from 'lucide-react';

export default function Layout() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-800 shadow-lg">
        <div className="p-6 border-b border-gray-700">
          <h1 className="text-2xl font-bold text-blue-400">ServiSoft VPN</h1>
          <p className="text-xs text-gray-400">Multicloud Manager</p>
        </div>

        <nav className="p-4 space-y-2">
          <NavLink icon={<BarChart3 size={20} />} to="/" label="Dashboard" />
          <NavLink icon={<Wifi size={20} />} to="/vpn-tunnels" label="Túneles VPN" />
          <NavLink icon={<Activity size={20} />} to="/metrics" label="Métricas" />
          <NavLink icon={<Route size={20} />} to="/bgp-routes" label="Rutas BGP" />
          <NavLink icon={<FileText size={20} />} to="/reports" label="Reportes" />
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg transition"
          >
            <LogOut size={18} /> Cerrar Sesión
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <Outlet />
      </div>
    </div>
  );
}

function NavLink({ icon, to, label }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-gray-700 transition"
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
}