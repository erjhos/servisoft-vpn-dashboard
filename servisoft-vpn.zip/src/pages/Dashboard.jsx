import { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle, Zap, Activity } from 'lucide-react';

export default function Dashboard() {
  const [tunnels, setTunnels] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    activos: 0,
    inactivos: 0,
    errores: 0
  });

  useEffect(() => {
    // Simular carga de datos
    const mockTunnels = [
      { id: 1, nombre: 'AWS-Azure', estado: 'activo', latencia: 12, disponibilidad: 99.8 },
      { id: 2, nombre: 'AWS-GCP', estado: 'activo', latencia: 8, disponibilidad: 99.5 },
      { id: 3, nombre: 'Azure-GCP', estado: 'inactivo', latencia: 0, disponibilidad: 0 }
    ];
    setTunnels(mockTunnels);
    setStats({
      total: 3,
      activos: 2,
      inactivos: 1,
      errores: 0
    });
  }, []);

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold">Dashboard</h1>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
        <Card title="Túneles Totales" value={stats.total} icon={<Zap className="text-blue-400" />} />
        <Card title="Activos" value={stats.activos} icon={<CheckCircle className="text-green-400" />} />
        <Card title="Inactivos" value={stats.inactivos} icon={<Activity className="text-yellow-400" />} />
        <Card title="Errores" value={stats.errores} icon={<AlertCircle className="text-red-400" />} />
      </div>

      {/* Lista de Túneles */}
      <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-700">
          <h2 className="text-xl font-bold">Estado de Túneles VPN</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left">Túnel</th>
                <th className="px-6 py-3 text-left">Estado</th>
                <th className="px-6 py-3 text-left">Latencia (ms)</th>
                <th className="px-6 py-3 text-left">Disponibilidad</th>
              </tr>
            </thead>
            <tbody>
              {tunnels.map(tunnel => (
                <tr key={tunnel.id} className="border-t border-gray-700 hover:bg-gray-700/50">
                  <td className="px-6 py-4">{tunnel.nombre}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      tunnel.estado === 'activo' ? 'bg-green-600' : 'bg-yellow-600'
                    }`}>
                      {tunnel.estado}
                    </span>
                  </td>
                  <td className="px-6 py-4">{tunnel.latencia} ms</td>
                  <td className="px-6 py-4">{tunnel.disponibilidad}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Card({ title, value, icon }) {
  return (
    <div className="bg-gray-800 rounded-lg p-6 flex items-center justify-between shadow-lg">
      <div>
        <p className="text-gray-400 text-sm">{title}</p>
        <p className="text-3xl font-bold">{value}</p>
      </div>
      <div className="text-4xl">{icon}</div>
    </div>
  );
}