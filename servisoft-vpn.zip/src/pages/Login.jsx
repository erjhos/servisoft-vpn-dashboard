import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login({ setIsAuthenticated }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    // Simular autenticación
    localStorage.setItem('token', 'mock-token-' + Date.now());
    setIsAuthenticated(true);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center">
      <div className="bg-gray-800 rounded-lg shadow-2xl p-8 w-96">
        <h1 className="text-3xl font-bold text-blue-400 mb-6">ServiSoft VPN</h1>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-gray-700 px-4 py-2 rounded-lg text-white placeholder-gray-400"
            required
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-gray-700 px-4 py-2 rounded-lg text-white placeholder-gray-400"
            required
          />
          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition font-semibold"
          >
            Iniciar Sesión
          </button>
        </form>

        <p className="text-center text-gray-400 text-sm mt-4">
          Demo: usa cualquier email y contraseña
        </p>
      </div>
    </div>
  );
}