import { useState } from 'react';
import { Plus, Edit2, Trash2 } from 'lucide-react';

export default function VpnTunnels() {
  const [showForm, setShowForm] = useState(false);
  const [tunnels, setTunnels] = useState([
    {
      id: 1,
      nombre: 'AWS-Azure',
      origen: 'AWS',
      destino: 'Azure',
      estado: 'activo',
      encriptacion: 'AES-256'
    },
    {
      id: 2,
      nombre: 'AWS-GCP',
      origen: 'AWS',
      destino: 'GCP',
      estado: 'activo',
      encriptacion: 'AES-256'
    }
  ]);

  const [formData, setFormData] = useState({
    nombre: '',
    origen: 'AWS',
    destino: 'Azure',
    encriptacion: 'AES-256'
  });

  const handleAddTunnel = () => {
    const newTunnel = {
      id: tunnels.length + 1,
      ...formData,
      estado: 'inactivo'
    };
    setTunnels([...tunnels, newTunnel]);
    setFormData({ nombre: '', origen: 'AWS', destino: 'Azure', encriptacion: 'AES-256' });
    setShowForm(false);
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Gestión de Túneles VPN</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition"
        >
          <Plus size={20} /> Nuevo Túnel
        </button>
      </div>

      {showForm && (
        <div className="bg-gray-800 rounded-lg p-6 space-y-4">
          <input
            type="text"
            placeholder="Nombre del túnel"
            value={formData.nombre}
            onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
            className="w-full bg-gray-700 px-4 py-2 rounded-lg text-white placeholder-gray-400"
          />
          <div className="grid grid-cols-3 gap-4">
            <select
              value={formData.origen}
              onChange={(e) => setFormData({ ...formData, origen: e.target.value })}
              className="bg-gray-700 px-4 py-2 rounded-lg text-white"
            >
              <option>AWS</option>
              <option>Azure</option>
              <option>GCP</option>
            </select>
            <select
              value={formData.destino}
              onChange={(e) => setFormData({ ...formData, destino: e.target.value })}
              className="bg-gray-700 px-4 py-2 rounded-lg text-white"
            >
              <option>Azure</option>
              <option>AWS</option>
              <option>GCP</option>
            </select>
            <select
              value={formData.encriptacion}
              onChange={(e) => setFormData({ ...formData, encriptacion: e.target.value })}
              className="bg-gray-700 px-4 py-2 rounded-lg text-white"
            >
              <option>AES-128</option>
              <option>AES-192</option>
              <option>AES-256</option>
            </select>
          </div>
          <button
            onClick={handleAddTunnel}
            className="w-full bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition"
          >
            Crear Túnel
          </button>
        </div>
      )}

      <div className="grid gap-4">
        {tunnels.map(tunnel => (
          <div key={tunnel.id} className="bg-gray-800 rounded-lg p-4 flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold">{tunnel.nombre}</h3>
              <p className="text-gray-400 text-sm">{tunnel.origen} → {tunnel.destino}</p>
              <p className="text-gray-400 text-sm">Encriptación: {tunnel.encriptacion}</p>
            </div>
            <div className="flex gap-2">
              <button className="p-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition">
                <Edit2 size={18} />
              </button>
              <button className="p-2 bg-red-600 hover:bg-red-700 rounded-lg transition">
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}